from typing import List

from project.product import Product


class ProductRepository:
    def __init__(self):
        self.products: List[Product] = []

    def add(self, product: Product):
        self.products.append(product)

    def find(self, product_name: str):
        return next(filter(lambda p: p.name == product_name, self.products), None)

    def remove(self, product_name: str):
        product_t = self.find(product_name)
        if product_t:
            self.products.remove(product_t)

    def __repr__(self):
        return "\n".join(f"{p.name}: {p.quantity}" for p in self.products)

