class Animal:
    # def __init__(self, name)
    def eat(self):
        return "eating..."
