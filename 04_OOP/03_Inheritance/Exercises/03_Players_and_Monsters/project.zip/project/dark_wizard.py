from project.wizard import Wizard


class DarkWizard(Wizard):
    pass
