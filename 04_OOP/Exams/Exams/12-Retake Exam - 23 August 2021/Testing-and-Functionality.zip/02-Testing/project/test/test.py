from project.library import Library

from unittest import TestCase, main


class Test(TestCase):
    def setUp(self) -> None:
        self.library = Library("asd")

    def test_correct_initialization(self):
        self.assertEqual("asd", self.library.name)

    def test_name_setter(self):
        with self.assertRaises(ValueError) as ve:
            self.library.name = ''

        self.assertEqual("Name cannot be empty string!", str(ve.exception))

    def test_add_book_if_new_author(self):
        self.library.add_book("new", "new book")

        self.assertEqual({"new": ["new book"]}, self.library.books_by_authors)

    def test_add_book_if_old_author_new_title(self):
        self.library.books_by_authors = {"a": ["old book"]}
        self.library.add_book("a", "new book")

        self.assertEqual({"a": ["old book", "new book"]}, self.library.books_by_authors)

    def test_add_book_if_old_author_old_title(self):
        self.library.books_by_authors = {"a": ["old book", "book1"]}
        self.library.add_book("a", "book1")

        self.assertEqual({"a": ["old book", "book1"]}, self.library.books_by_authors)

    def test_add_reader_if_new(self):
        self.library.readers = {"reader": ["book", "book1"]}
        expected = {"reader": ["book", "book1"], "reader1": []}
        self.library.add_reader("reader1")

        self.assertEqual(expected, self.library.readers)

    def test_add_reader_if_exists(self):
        self.library.readers = {"reader": ["book", "book1"]}
        expected = "reader is already registered in the asd library."

        self.assertEqual({"reader": ["book", "book1"]}, self.library.readers)
        self.assertEqual(expected, self.library.add_reader("reader"))

    def test_rent_book_if_not_reader(self):
        expected = "reader is not registered in the asd Library."

        self.assertEqual(expected, self.library.rent_book("reader", "author", "title"))

    def test_rent_book_if_not_author(self):
        self.library.books_by_authors = {"a": ["old book"]}
        self.library.readers = {"reader": ["book", "book1"]}
        expected = "asd Library does not have any author's books."

        self.assertEqual(expected, self.library.rent_book("reader", "author", "title"))

    def test_rent_book_if_not_book(self):
        self.library.books_by_authors = {"author": ["old book", "book1"], "author1": ["old book12", "book112"]}
        self.library.readers = {"reader": ["book", "book1"]}
        expected = """asd Library does not have author's "title"."""

        self.assertEqual(expected, self.library.rent_book("reader", "author", "title"))

    def test_rent_book(self):
        self.library.books_by_authors = {"author": ["old book", "book1"], "author1": ["old book12", "book112"]}
        self.library.readers = {"reader": [{"author": "book111"}]}
        self.library.rent_book("reader", "author", "book1")
        expected = {"reader": [{"author": "book111"}, {"author": "book1"}]}
        expected1 = {"author": ["old book"], "author1": ["old book12", "book112"]}

        self.assertEqual(expected, self.library.readers)
        self.assertEqual(expected1, self.library.books_by_authors)


if __name__ == "__main__":
    main()
