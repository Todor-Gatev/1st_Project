from project.animal import Animal
from abc import abstractmethod


class Cat(Animal):
    @abstractmethod
    def make_sound(self) -> str:
        return "Meow meow!"
