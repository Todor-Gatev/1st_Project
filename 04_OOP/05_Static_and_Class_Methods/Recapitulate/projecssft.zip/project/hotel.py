from typing import List

from project.room import Room


class Hotel:
    def __init__(self, name: str):
        self.name = name
        self.rooms: List[Room] = []
        self.guests = 0

    @classmethod
    def from_stars(cls, stars_count: int):
        return cls(f"{stars_count} stars Hotel")

    def add_room(self, room: Room) -> None:
        self.rooms.append(room)

    @staticmethod
    def find_object(collection: list, attribute: str, value: str):
        for obj in collection:
            if str(getattr(obj, attribute)) == value:
                return obj

    def take_room(self, room_number: int, people: int) -> None:
        room = self.find_object(self.rooms, "number", str(room_number))
        if not room.is_taken and room.capacity >= people:
            room.is_taken = True
            room.guests = people
            self.guests += people

    def free_room(self, room_number: int):
        room = self.find_object(self.rooms, "number", str(room_number))
        if room.is_taken:
            self.guests -= room.guests
            room.is_taken = False
            room.guests = 0

    def status(self) -> str:
        free_rooms = ", ".join(str(r.number) for r in self.rooms if not r.is_taken)
        taken_rooms = ", ".join(str(r.number) for r in self.rooms if r.is_taken)

        # for r in self.rooms:
        #     if r.is_taken:
        #         taken_rooms.append(r)
        #     else:
        #         free_rooms.append(r)

        return (f"Hotel {self.name} has {self.guests} total guests\n"
                f"Free rooms: {free_rooms}\n"
                f"Taken rooms: {taken_rooms}")

