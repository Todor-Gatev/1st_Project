from typing import List

from project.player import Player


class Guild:
    def __init__(self, name: str):
        self.name = name
        self.players: List[Player] = []

    def assign_player(self, play_er: Player) -> str:
        if play_er in self.players:
            return f"Player {play_er.name} is already in the guild."

        if not play_er.guild == "Unaffiliated":
            return f"Player {play_er.name} is in another guild."

        play_er.guild = self.name
        self.players.append(play_er)

        return f"Welcome player {play_er.name} to the guild {self.name}"

    def kick_player(self, player_name: str) -> str:
        play_er = next(filter(lambda p: p.name == player_name, self.players), None)

        if not play_er:
            return f"Player {player_name} is not in the guild."

        play_er.guild = "Unaffiliated"
        self.players.remove(play_er)

        return f"Player {player_name} has been removed from the guild."

    def guild_info(self):
        return f"Guild: {self.name}\n" + "\n".join(p.player_info() for p in self.players)


player = Player("George", 50, 100)
print(player.add_skill("Shield Break", 20))
print(player.player_info())
guild = Guild("UGT")
print(guild.assign_player(player))
print(guild.guild_info())
