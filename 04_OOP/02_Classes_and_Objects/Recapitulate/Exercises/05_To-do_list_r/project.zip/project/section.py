from typing import List

from project.task import Task


class Section:
    def __init__(self, name):
        self.name = name
        self.tasks: List[Task] = []
        self.completed_tasks = set()

    def add_task(self, new_task: Task):
        if new_task in self.tasks:
            return f"Task is already in the section {self.name}"

        self.tasks.append(new_task)

        return f"Task {new_task.details()} is added to the section"

    def complete_task(self, task_name: str):
        task = next(filter(lambda t: t.name == task_name, self.tasks), None)

        if not task:
            return f"Could not find task with the name {task_name}"

        task.completed = True
        self.completed_tasks.add(task)

        return f"Completed task {task_name}"

    def clean_section(self):
        removed_tasks = len(self.completed_tasks)
        self.tasks = list(self.completed_tasks.symmetric_difference(self.tasks))
        self.completed_tasks.clear()

        # for idx in range(len(self.tasks) - 1, -1, -1):
        #     if self.tasks[idx].completed:
        #         removed_tasks += 1
        #         self.tasks.pop(idx)

        return f"Cleared {removed_tasks} tasks."

    def view_section(self):
        res = [
            f"Section {self.name}:",
            *[t.details() for t in self.tasks]
        ]

        return "\n".join(res)
